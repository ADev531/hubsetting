#!/usr/local/bin/python3
# -*- coding:utf-8 -*-

from users import *
from tkinter import * 
import sys
import io

sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding = 'euc-kr')
sys.stderr = io.TextIOWrapper(sys.stderr.detach(), encoding = 'euc-kr')


win = Tk()
win.title("Settings")
win.option_add("*Font","서울한강체 20")
win.geometry("1500x750")

searchbar = Entry(win)
userbtn = Button(win)
defendbtn = Button(win)

userbtn.config(text="Users")
defendbtn.config(text="Defend")
searchbar.pack()
userbtn.pack()
defendbtn.pack()
win.mainloop()
print ("Hub OS Settings")
