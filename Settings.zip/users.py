#!/usr/local/bin/python3

from main import *
from tkinter import *

userwin = Tk()

userwin.title("유저 - 설정")
userwin.option_add("*Font","서울한강체 20")
